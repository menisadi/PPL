/**
 */
public class OneDNode extends Node {

    public OneDNode left;
    public OneDNode right;
    public OneDNode parent;
    public int leavesUnderNode;
}
