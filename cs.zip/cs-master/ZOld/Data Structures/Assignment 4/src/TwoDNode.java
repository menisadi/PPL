/**
 */
public class TwoDNode extends Node {
    OneDRangeTree yTree;

    public TwoDNode left;
    public TwoDNode right;
    public TwoDNode parent;
}
