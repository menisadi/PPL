/**
 */
public abstract class Node {
    public Point data;
    public Node left;
    public Node right;
    public Node parent;
}
