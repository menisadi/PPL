
public class UserListNode {
	public UserListNode Next;
	public User CurrUser; 
	
}
