package boundedStack;

public class BoundedStackImpl {

}
