package tokenizer;

public interface Message<T> {

}
