/**
 * 
 */
/**
 * @author yotam
 *
 */
package encoder;