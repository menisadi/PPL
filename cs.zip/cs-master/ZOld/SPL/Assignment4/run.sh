#!/bin/bash
ant -Darg0=6666
