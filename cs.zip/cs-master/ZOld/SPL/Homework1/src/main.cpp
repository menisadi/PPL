#include <iostream>
#include include/homework1.h

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}

