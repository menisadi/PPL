#include <iostream>
#include "include/homework1.h"

using namespace std;

int main()
{

    cout << base2(4) << endl;
    printWords(split("THIS IS AN EXAMPLE OF A SENTENCE"));
    return 0;
}
