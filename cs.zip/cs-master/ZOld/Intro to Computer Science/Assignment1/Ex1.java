public class Ex1 {
	public static void main(String[] args) {

        for (int current_number = 4; current_number <= 648; current_number = current_number + 4) {
            // Print all numbers that divide by for until 648.
            System.out.println(current_number);
        }
	}
}
