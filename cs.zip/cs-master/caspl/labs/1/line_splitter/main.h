int isNumber(char c);
char * read();
void printLine();
void workLine(char *line);
FILE * input;
int flagS;
int flagD;
int lineNum;
char flag;