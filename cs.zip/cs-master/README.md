CS Courses homework/assigment files.
