package shmuel;

public interface Operator {
	public int operate(int x, int y);
}
