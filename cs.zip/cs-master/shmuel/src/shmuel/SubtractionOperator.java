package shmuel;

public class SubtractionOperator implements Operator {

	@Override
	public int operate(int x, int y) {
		return x-y;
	}
}