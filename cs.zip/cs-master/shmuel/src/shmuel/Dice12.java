package shmuel;

public class Dice12 implements Dice {
	/* Number of sides to the dice. */
	private int sides = 12;

	/**
	 * Roll the dice.
	 * @return
	 *  A random number between 1 and this.sides.
	 */
	public int roll() {
		int result =  (int) Math.round((Math.random() * (this.sides - 1)) + 1); 
		return result;
	}

	/**
	 * Roll the dice.
	 * @param times
	 *  Number of times to roll the dice.
	 * @return
	 *  Sum of all the rolls.
	 * @see shmuel.Dice12#roll
	 */
	public int roll(int times) {
		int result = 0;
		
		for (int index = 0; index < times; index++ ) {
			result +=  this.roll();
		}
		return result;
	}
}
