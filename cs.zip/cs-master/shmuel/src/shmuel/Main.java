	

package shmuel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		
		String s ="";
		System.out.println("Enter something here : ");
	 
		try{
		    BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
		  s = bufferRead.readLine();
	 
		    System.out.println(s);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		String[] parts = s.split(" ");
		int firstnum = Integer.parseInt(parts[0]); 
		int secondnum =Integer.parseInt(parts[2]);
		
		String operatorString = parts[1]; 
		Operator operator;
		switch(operatorString) {
		case "+":
			operator = new AdditionOperator();
			break;
		case "-":
			operator = new SubtractionOperator();
			break;
		default:
			operator = new AdditionOperator();
			break;
		}
		
		int result = operator.operate(firstnum, secondnum);
		
		System.out.println(result);
	}
}