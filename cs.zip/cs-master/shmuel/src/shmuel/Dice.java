package shmuel;

public interface Dice {
	public int roll();
	public int roll(int times);
}
